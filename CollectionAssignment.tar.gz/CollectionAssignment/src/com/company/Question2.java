package com.company;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

public class Question2 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a word");
        String word = sc.next();
        uniqueCharacter(word);
    }
    private static void uniqueCharacter(String word) {
        Set<Character> s=new HashSet<>();
        for (int i = 0; i < word.length(); i++){
            //Checks whether a character exist in the set or not if not then add else ignore.

            if (!s.contains(word.charAt(i))){
                s.add(word.charAt(i));
            }
        }
        Iterator<Character> it=s.iterator();
        System.out.println("Unique characters are:");
        while(it.hasNext())
        {
            System.out.print(it.next());
        }
    }
}
