package com.company;

import java.util.ArrayList;
import java.util.List;


public class Question7 {

    int capacity = 0, top = 0, top1 = 0;

    public Question7(int capacity) {
        this.capacity = capacity;
    }

    List<Integer> listOfElements = new ArrayList<>();
    List<Integer> minElement = new ArrayList<>();

    public void push(int elementToBePushed) {
        //checking whether stack is full or not
        if (isFull())
            System.out.println("Stack Full");
        else {
            if (listOfElements.isEmpty() || minElement.isEmpty()) {
                listOfElements.add(elementToBePushed);
                minElement.add(elementToBePushed);
            } else {
                listOfElements.add(elementToBePushed);
                int y = minElement.get(top1 - 1);
                if (elementToBePushed < y) {
                    minElement.add(elementToBePushed);
                } else {
                    minElement.add(y);
                }

            }
            top++;
            top1++;

        }
    }

    public void pop() {
        //checking whether stack is empty or not
        if (isEmpty())
            System.out.println("Stack Empty");
        else {
            int r = listOfElements.remove(top - 1);
            minElement.remove(top1 - 1);
            System.out.println("Removed element is" + r);
            top--;
            top1--;
        }
    }

    public boolean isEmpty() {
        if (listOfElements.isEmpty())
            return true;
        else
            return false;
    }

    public boolean isFull() {
        if (listOfElements.size() == capacity)
            return true;
        else
            return false;
    }

    public void displayStack() {
        if (!listOfElements.isEmpty()) {
            System.out.println("Elements of the Stack are");
            for (Integer ite : listOfElements) {
                System.out.println(ite);
            }
        } else
            System.out.println("Stack Empty");
    }


    public int getMin() {
        return minElement.get(top1 - 1);

    }

    public static void main(String[] args) {
        Question7 s = new Question7(5);
        s.push(4);
        s.push(2);
        s.push(1);
        s.push(9);
        s.push(5);

        s.displayStack();

        System.out.println("Pushing element in the stack after the capacity of it");
        s.push(7);

        s.displayStack();

        s.pop();
        s.pop();

        s.displayStack();

        System.out.println("Pushing element in the stack  which is 6");
        s.push(6);

        s.displayStack();

        System.out.println("Minimuin Element of the Stack is " + s.getMin());

        System.out.println("Poping all the elements from the stack");

        s.pop();
        s.pop();
        s.pop();
        s.pop();

        s.displayStack();

    }
}
