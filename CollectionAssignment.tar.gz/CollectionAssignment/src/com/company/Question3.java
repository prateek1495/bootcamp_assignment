package com.company;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Question3 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter a word");
        String word = sc.next();
        uniqueCharacter(word);
    }

    private static void uniqueCharacter(String word) {
        //Creating a HashMap containing char
        // as a key and occurrences as  a value
        Map<Character,Integer>m=new HashMap<>();
        // Converting given string to char array
        char wordArray[]=word.toCharArray();
        // checking each char of wordArray
        for(char k:wordArray)
        {
            // If char is present in map,incrementing it's count by 1
            if(m.containsKey(k))
            {
                m.put(k,m.get(k)+1);
            }

            // If char is not present in map,putting this char to map with 1 as it's value

            else
            {
                m.put(k,1);
            }
        }
        // Printing the charCountMap
        for(Map.Entry e:m.entrySet())
        {
            System.out.println("Character::"+e.getKey()+" "+" "+" "+"Occurences::"+e.getValue());
        }
    }


}
