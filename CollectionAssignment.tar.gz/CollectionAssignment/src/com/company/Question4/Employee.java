package com.company.Question4;

import java.util.*;

public class Employee implements Comparable<Employee> {
    private int id;
    private String name;
    private int salary;
    private int age;

    public static  Comparator<Employee> AgeComparator = new Comparator<Employee>() {

        @Override
        public int compare(Employee o1, Employee o2) {
            return o1.age - o2.age;  // This will work because age is positive integer
        }

    };

    public static  Comparator<Employee> SalaryComparator = new Comparator<Employee>() {

        @Override
        public int compare(Employee o1, Employee o2) {
            return o2.salary - o1.salary; // salary is also positive integer
        }

    };

    public Employee(int id, String name, int salary, int age) {
        this.id = id;
        this.name = name;
        this.salary = salary;
        this.age = age;
    }

    @Override
    public String toString() {
        return "Employee{" + "id=" + id + ", name=" + name + ", salary=" + salary + ", age=" + age + "}";
    }

    @Override
    public int compareTo(Employee o) {
        return this.id - o.id;
    }

    public static void main(String[] args) {
        List<Employee> employees = new ArrayList<>();
        employees.add(new Employee(10, "Prateek", 25000, 23));
        employees.add(new Employee(10, "Gagan", 32000, 24));
        employees.add(new Employee(10, "Lohit", 30000, 25));
        Collections.sort(employees,Employee.SalaryComparator);
        employees.forEach(System.out::println);
    }

}