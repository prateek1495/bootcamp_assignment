package com.company.Question4;

import java.util.Arrays;
import java.util.Comparator;

public class Employee implements Comparable<Employee> {
    private int id;
    private String name;
    private int salary;
    private int age;

    public static final Comparator<Employee> AgeComparator = new Comparator<Employee>() {

        @Override
        public int compare(Employee o1, Employee o2) {
            return o1.age - o2.age;  // This will work because age is positive integer
        }

    };

    public static final Comparator<Employee> SalaryComparator = new Comparator<Employee>() {

        @Override
        public int compare(Employee o1, Employee o2) {
            return o1.salary - o2.salary; // salary is also positive integer
        }

    };

    public Employee(int id, String name, int salary, int age) {
        this.id = id;
        this.name = name;
        this.salary = salary;
        this.age = age;
    }

    @Override
    public String toString() {
        return "Employee{" + "id=" + id + ", name=" + name + ", salary=" + salary + ", age=" + age + "}";
    }

    @Override
    public int compareTo(Employee o) {
        return this.id - o.id;
    }

    public static void main(String[] args) {
        Employee[] empArr = new Employee[4];
        empArr[0] = new Employee(10, "Prateek", 25000, 23);
        empArr[1] = new Employee(20, "Lohit", 29000, 22);
        empArr[2] = new Employee(5, "Vagish", 35000, 22);
        empArr[3] = new Employee(1, "Gagan", 32000, 23);
        System.out.println(Arrays.toString(empArr));
        System.out.println(" ");
        Arrays.sort(empArr, Employee.SalaryComparator);
        System.out.println("Employees list sorted by Salary:\n\n"+Arrays.toString(empArr));

    }

}