package com.company;

import sun.awt.datatransfer.DataTransferer;

import java.util.*;
import java.util.Map.Entry;

public class Question6 {

    public static LinkedHashMap<Integer, Integer> sortedMap(LinkedHashMap<Integer, Integer> hm) {
        List<Entry<Integer, Integer>> list = new LinkedList<Entry<Integer, Integer>>(hm.entrySet());
        Collections.sort(list, new Comparator<Entry<Integer, Integer>>() {
            @Override
            public int compare(Entry<Integer, Integer> o1, Entry<Integer, Integer> o2) {
                return -(o1.getValue().compareTo(o2.getValue()));
            }
        });
        LinkedHashMap<Integer, Integer> lm = new LinkedHashMap<>();
        for (Map.Entry<Integer, Integer> e : list) {
            lm.put(e.getKey(), e.getValue());
        }
        return lm;
    }

    public static void main(String[] args) {
        LinkedHashMap<Integer, Integer>hm= new LinkedHashMap<>();
        int arr[]={2,2,3,4,4,5,6,1,1,6,8,7,9};
        for(int i=0;i<arr.length;i++)
        {
            if(hm.containsKey(arr[i]))
            {
                hm.put(arr[i],hm.get(arr[i])+1);
            }
            else
            {
                hm.put(arr[i],1);
            }
        }
        LinkedHashMap<Integer,Integer>sortedMap= sortedMap(hm);
        System.out.println("Sorted Map"+sortedMap);

    }
}
