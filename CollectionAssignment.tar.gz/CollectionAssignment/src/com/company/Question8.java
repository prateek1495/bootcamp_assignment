package com.company;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Question8 {
    public static void main(String[] args) {

        String pattern = "dd-MMMM-yyyy";
        DateFormat dateFormat = new SimpleDateFormat(pattern);
        String date = dateFormat.format(new Date());
        System.out.println(date);

    }
}
