package com.company;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

public class Question9 {
    public static void main(String[] args) {
        Date d1 = new Date();
        System.out.println("today is "+ d1.toString());
        Locale locItalian = new Locale("it","ch");
        Locale locFrance = new Locale("fr","FR");
        DateFormat df = DateFormat.getDateInstance(DateFormat.FULL, locItalian);
        DateFormat df1 = DateFormat.getDateInstance(DateFormat.FULL,locFrance);
        System.out.println("today is in Italian Language : "+ df.format(d1));
        System.out.println("today is in French Language  : "+ df1.format(d1));

    }
}
