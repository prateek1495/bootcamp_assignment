package com.company;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Question1 {
    public static void main(String[] args) {

        //ArrayList
        List<Float> l=new ArrayList<>();
        float sum=0.0f;
        l.add(2.5f);
        l.add(3.5f);
        l.add(5.6f);
        l.add(4.3f);
        l.add(1.7f);
        //Iterator
        Iterator<Float>i=l.iterator();
        while(i.hasNext())
        {
            sum+=i.next();
        }

        System.out.println("Sum is::"+sum);

    }
}
