package com.company.Question5;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Student implements Comparable<Student> {

    String name;
    double score;
    double age;

    public Student(String name, double score, double age) {
        this.name = name;
        this.score = score;
        this.age=age;
    }


    @Override
    public int compareTo(Student o) {
        if (o == null) {
            return -1;
        }
        int c = Double.valueOf(score).compareTo(o.score);
        if (c != 0) {
            return c;
        }
        return name.compareTo(o.name);
    }

    @Override
    public String toString() {
        return String.format("%s has score %.2f", name, score);
    }

    public static void main(String[] args) {
        List<Student> al = new ArrayList<>();
        al.add(new Student("Prateek", 3434.34,23));
        al.add(new Student("Vagish", 99.22,22));
        al.add(new Student("Lohit", 1378.00,21));
        al.add(new Student("Gagan", 99.22,23));
        al.add(new Student("Arpit", 19.08,22));
        Collections.sort(al);
        System.out.println(al);
    }
}