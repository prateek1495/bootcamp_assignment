package Jdbc.Question6;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Question6 {
    public static void main(String[] args) {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("Spring-config.xml");
        UserDAO userDAO=ctx.getBean(UserDAO.class);
        System.out.println(userDAO.getUserName());
    }
}
