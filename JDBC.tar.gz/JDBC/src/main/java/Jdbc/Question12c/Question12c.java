package Jdbc.Question12c;

import Jdbc.Question12.UserDao12;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Question12c {
    public static void main(String[] args) {

        ApplicationContext ctx=new ClassPathXmlApplicationContext("Spring-config.xml");
        UserDao12c userDao =ctx.getBean(UserDao12c.class);
        userDao.insert();
    }
}
