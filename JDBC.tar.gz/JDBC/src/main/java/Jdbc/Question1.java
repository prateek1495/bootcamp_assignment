package Jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Question1 {
    // driverName which is passed in Class.forName to load the driver of a particular class in runtime
    String driverName="com.mysql.jdbc.Driver";

    // connection is used to make the connection with the database using the particular url,username and password
    Connection connection;

    // url to specific which database we want to connect
    String url="jdbc:mysql://localhost:3306/springDemo";
    // to provide the username to access the database
    String user="prateek123";
    // to provide the password to access the database
    String password="Prateek@14";
    // to create mysql querys and execute them
    PreparedStatement preparedStatement;

    void createConnection()
    {
        try {
            Class.forName(driverName);
            connection= DriverManager.getConnection(url, user, password);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    void createDatabase()
    {
        String sql="create table user(username VARCHAR(100), password VARCHAR(100), name VARCHAR(100), age INT(10), dob DATE)";
        try {
            preparedStatement=connection.prepareStatement(sql);
            preparedStatement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Question1 question1 = new Question1();
        question1.createConnection();
        question1.createDatabase();
    }
}
