package Jdbc.Question12b;

import Jdbc.Question12.UserDao12;
import Jdbc.Question5.UserDao;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Question12b {
    public static void main(String[] args) {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("Spring-config.xml");
        UserDao12b userDao =ctx.getBean(UserDao12b.class);
        userDao.insert();
    }
}
