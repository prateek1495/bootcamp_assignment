package Jdbc.Question12g;

import Jdbc.Question12f.UserDao12f;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Question12g {
    public static void main(String[] args) {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("Spring-config.xml");
        UserDao12g userDao=ctx.getBean(UserDao12g.class);
        userDao.insert();
    }
}
