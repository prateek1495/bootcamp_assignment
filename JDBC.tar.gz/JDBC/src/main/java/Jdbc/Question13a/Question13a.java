package Jdbc.Question13a;

import Jdbc.Question13.UserDao14;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Question13a {
    public static void main(String[] args) {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("Spring-config.xml");
        UserDao14a userDao=ctx.getBean(UserDao14a.class);
        userDao.insert();
    }
}
