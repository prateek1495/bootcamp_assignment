package Jdbc.Question11;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Question11 {
    public static void main(String[] args) {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("Spring-config.xml");
        UserDao11 userDao=ctx.getBean(UserDao11.class);
        userDao.sessionFactoryDemo();
    }
}
