package Jdbc.Question12d;

import Jdbc.Question12c.UserDao12c;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Question12d {
    public static void main(String[] args) {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("Spring-config.xml");
        UserDao12d userDao=ctx.getBean(UserDao12d.class);
        userDao.insert();
    }
}
