package Jdbc.Question13c;

import Jdbc.Question13b.UserDao14b;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Question13c {
    public static void main(String[] args) {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("Spring-config.xml");
        UserDao14c userDao=ctx.getBean(UserDao14c.class);
        userDao.insert();
    }
}
