package Jdbc.Question13b;

import Jdbc.Question13a.UserDao14a;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Question13b {
    public static void main(String[] args) {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("Spring-config.xml");
        UserDao14b userDao=ctx.getBean(UserDao14b.class);
        userDao.insert();
    }
}
