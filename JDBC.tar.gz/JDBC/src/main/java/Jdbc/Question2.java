package Jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Question2 {
    // driverName which is passed in Class.forName to load the driver of a particular class in runtime
    String driverName="com.mysql.jdbc.Driver";

    // connection is used to make the connection with the database using the particular url,username and password
    Connection connection;

    // url to specific which database we want to connect
    String url="jdbc:mysql://localhost:3306/springDemo";
    // to provide the username to access the database
    String user="prateek123";
    // to provide the password to access the database
    String password="Prateek@14";
    // to create mysql querys and execute them
    PreparedStatement preparedStatement;

    void createConnection()
    {
        try {
            Class.forName(driverName);
            connection= DriverManager.getConnection(url, user, password);
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }

    void createDatabase()
    {
        String sql="insert into user(username,password,name,age,dob) values ('Lohit','ahooja','Lohit Ahooja',22,'1997-02-13'),('Gagan','Khushwah','Gagan Khushwah',25,'1995-02-11'),('Prateek','Nagar','Prateek Nagar',25,'1995-11-14'),('Aprit','Gupta','Aprit Gupta',25,'1995-08-28')";
        try {
            preparedStatement=connection.prepareStatement(sql);
            preparedStatement.execute();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        Question2 question2 = new Question2();
        question2.createConnection();
        question2.createDatabase();
    }
}
