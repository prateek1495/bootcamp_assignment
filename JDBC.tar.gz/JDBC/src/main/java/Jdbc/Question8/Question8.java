package Jdbc.Question8;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Question8 {
    public static void main(String[] args) {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("Spring-config.xml");
        UserDao8 userDao=ctx.getBean(UserDao8.class);
        userDao.queryForMapDemo();
    }
}
