package Jdbc.Question9;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Question9 {
    public static void main(String[] args) {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("Spring-config.xml");
        UserDao9 userDao=ctx.getBean(UserDao9.class);
        userDao.queryForListDemo();
    }
}
