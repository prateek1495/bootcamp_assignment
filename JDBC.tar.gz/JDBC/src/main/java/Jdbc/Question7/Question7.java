package Jdbc.Question7;


import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.util.Date;

public class Question7 {
    public static void main(String[] args) {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("Spring-config.xml");
      UserDao7 userDAO=ctx.getBean(UserDao7.class);
        User user=new User();
        user.setAge(23);
        user.setUsername("arpit");
        user.setName("Arpit");
        user.setPassword("123");
        user.setDob(new Date());
        userDAO.insertUser(user);
    }
}
