package Jdbc.Question12f;

import Jdbc.Question12e.UserDao12e;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Question12f {
    public static void main(String[] args) {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("Spring-config.xml");
        UserDao12f userDao=ctx.getBean(UserDao12f.class);
        userDao.insert();
    }
}
