package Jdbc.Question12e;

import Jdbc.Question12d.UserDao12d;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Question12e {
    public static void main(String[] args) {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("Spring-config.xml");
        UserDao12e userDao=ctx.getBean(UserDao12e.class);
        userDao.insert();
    }
}
