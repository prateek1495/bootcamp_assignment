package Jdbc.Question13;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Question13 {
    public static void main(String[] args) {
        ApplicationContext ctx=new ClassPathXmlApplicationContext("Spring-config.xml");
        UserDao14 userDao=ctx.getBean(UserDao14.class);
        userDao.insert();
    }
}
