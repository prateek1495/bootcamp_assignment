package Jdbc.Question13;

import Jdbc.Question12g.UserDao13g;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.util.Date;

@Repository
public class UserDao14 {

    @Autowired
    DataSource dataSource;

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Autowired
    UserDao15 userDao15;

    @Transactional(propagation= Propagation.REQUIRED , readOnly = true)
    public void insert() {

        try {
            Thread.sleep(2000L);
        } catch (InterruptedException e) {

        }

        String sql = "INSERT INTO user (username,password,name,age,dob)VALUES(?,?,?,?,?)";
        jdbcTemplate.update(sql, new Object[]{
                "xyz", "xyz", "xyz", 1, new Date()
        });
        try {
            userDao15.insert();
        } catch (Exception ex) {

        }
    }

}
