package com.company.Question1;

public interface User {
    void getUser();
}
