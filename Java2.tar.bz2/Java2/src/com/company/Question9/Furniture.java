package com.company.Question9;

abstract class Furniture{
    String type;
    abstract boolean getStressTestStatus();
    abstract boolean getFireTestStatus();
    abstract void result();
    abstract String getType();
}

