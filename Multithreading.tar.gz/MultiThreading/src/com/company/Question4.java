package com.company;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Question4 {

    public static void main(String[] args) {
        ExecutorService executorService = Executors.newSingleThreadExecutor();
        try {
            executorService.submit(new Runnable() {
                @Override
                public void run() {
                    System.out.println("Thread 1");
                }
            });

            executorService.submit(new Runnable() {
                @Override
                public void run() {
                    System.out.println("Thread 2");
                }
            });

            executorService.submit(new Runnable() {
                @Override
                public void run() {
                    try {
                        Thread.sleep(3000L);
                    } catch (InterruptedException e) {
                        e.getMessage();
                    }
                    System.out.println("Thread 3");
                }
            });

        } finally {
            executorService.shutdown();
                /*ShutDown()->Rejects New Task submitted to the thread executor while
                  continuing to execute any previously submitted task.*/
        }
        System.out.println("End");


    }
}


