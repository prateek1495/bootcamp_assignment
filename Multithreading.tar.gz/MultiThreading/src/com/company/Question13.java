package com.company;

public class Question13 {

    public void worker1() {
        synchronized (this) {
            System.out.println("Worker1 Started");
            try {
                wait(); //worker 1 will wait
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("Worker1 Done");
        }
    }


    public void worker2() {
        synchronized (this) {
            System.out.println("Worker 2 Started");
            System.out.println("Worker 2 Done");
            notify(); //after task done it will notify the worker1
        }
    }

    public static void main(String[] args) {
        Question13 q13 = new Question13();
        new Thread(new Runnable() {
            @Override
            public void run() {
                q13.worker1();
            }
        }).start();
        new Thread(new Runnable() {
            @Override
            public void run() {
                q13.worker2();
            }
        }).start();
    }
}
