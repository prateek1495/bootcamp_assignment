package com.company;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Question16 {


    //Deadlock Situation

    Lock lock1 = new ReentrantLock(true);
    Lock lock2 = new ReentrantLock(true);

    public void worker1() {
        //acquire lock1
        lock1.lock();
        System.out.println("lock 1 worker 1");
        //acquire lock2
        lock2.lock();
        System.out.println("lock 2 worker 1");
        //lock1 unlock
        lock1.unlock();
        //lock2 unlock
        lock2.unlock();
    }


    public void worker2() {
        //acquire lock2
        lock2.lock();
        System.out.println("lock 2 worker 2");
        //acquire lock1
        lock1.lock();
        System.out.println("lock 1 worker 2");
        //lock2 unlock
        lock2.unlock();
        //lock1 unlock
        lock1.unlock();
    }

    //Deadlock will occur when worker 1 acquire lock1 and worker 2 will acquire lock 2
    // and now worker want lock2 and worker 2 want lock 1 this will cause deadlock

    public static void main(String[] args) throws InterruptedException {
        Question16 q16 = new Question16();
        Thread thread1 = new Thread(new Runnable() {
            @Override
            public void run() {
                q16.worker1();
            }
        });
        Thread thread2 = new Thread(new Runnable() {
            @Override
            public void run() {
                q16.worker2();
            }
        });
        thread1.start();
        thread2.start();
        thread1.join();
        thread2.join();
    }
}

