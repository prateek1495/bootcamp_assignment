package com.company;

//implements Runnable interface
public class Question1 implements Runnable {


    @Override
    public void run() {
        System.out.println("Thread running");

    }

    public static void main(String[] args) {
        //Thread start
        new Thread(new Question1()).start();
        System.out.println("Main Thread");
    }

}
