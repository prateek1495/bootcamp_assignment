package com.company;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Question9b {

    public static void main(String[] args) {

        ExecutorService executorService = Executors.newCachedThreadPool();

        for (int i = 0; i <= 30; i++) {
            executorService.submit(new Proces(i));
        }
        executorService.shutdown();
    }
}

class Proces implements Runnable {
    int id;

    public Proces(int id) {
        this.id = id;
    }

    @Override
    public void run() {
        System.out.println("Thread name::" + Thread.currentThread().getName() + " Start :" + id);
        try {
            Thread.sleep(2000L);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Thread name::" + Thread.currentThread().getName() + " End :" + id);
    }

}
