package com.company;

public class Question2 {
    public static void main(String[] args) throws InterruptedException {
        //Thread 1

        Thread t1 = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(3000L);
                    System.out.println("Thread 1 Running");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }
        });

        //Thread 2
        Thread t2 = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Thread.sleep(2000L);
                    System.out.println("Thread 2 running");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });
        t1.start();
        t2.start();
        t1.join();
        t2.join();
        //Wait until the Thread 1 and Thread 2 finishes.
        System.out.println("Main Finished");

    }
}
