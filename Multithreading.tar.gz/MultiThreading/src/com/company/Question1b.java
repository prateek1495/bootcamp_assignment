package com.company;

//Extends Thread class
public class Question1b extends Thread {
    @Override
    public void run() {
        System.out.println(Thread.currentThread().getName() + "running");
    }

    public static void main(String[] args) {
        Question1b q1 = new Question1b();
        q1.start();
        System.out.println("Main Thread running");
    }

}
