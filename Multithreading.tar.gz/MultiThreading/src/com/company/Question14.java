package com.company;

public class Question14 {

    public void worker1() {
        synchronized (this) {
            System.out.println("Worker1 Started");
            try {
                wait(); //worker1 will wait
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("Worker1 Done");
        }
    }

    public void worker2() {
        synchronized (this) {
            System.out.println("Worker 2 Started");
            try {
                wait(); //worker2 will wait
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("Worker 2 Done");
        }
    }

    public void worker3() {
        synchronized (this) {
            System.out.println("Worker 3 Started");
            try {
                wait(); //worker3 will wait
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("Worker 3 Done");
        }
    }


    public void worker4() {
        synchronized (this) {
            System.out.println("Worker 4 Started");
            System.out.println("Worker 4 Done");
            notifyAll();
            //after its task done it will notify all the other threads
            // and it will work as stack pop(worker 3 will be called
        }
    }

    public static void main(String[] args) {
        Question14 q14 = new Question14();
        new Thread(new Runnable() {
            @Override
            public void run() {
                q14.worker1();
            }
        }).start();
        new Thread(new Runnable() {
            @Override
            public void run() {
                q14.worker2();
            }
        }).start();
        new Thread(new Runnable() {
            @Override
            public void run() {
                q14.worker3();
            }
        }).start();
        new Thread(new Runnable() {
            @Override
            public void run() {
                q14.worker4();
            }
        }).start();
    }
}

