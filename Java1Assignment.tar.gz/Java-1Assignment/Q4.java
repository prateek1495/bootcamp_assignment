import java.text.DecimalFormat;

public class Q4 {
    
    String str = "hello World @ 999 km/hr";
    
    public void characterPercentage() {
        
        // Initialize the totalChars with the string length
        
        int totalChars = str.length();
        
        /*
        Initialize the upperCase ,lowerCase,digits and others total to 0
        */
        int upperCaseTotal = 0;
        int lowerCaseTotal = 0;
        int digitsTotal = 0;
        int othersTotal = 0;
        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);
            if (Character.isUpperCase(ch)) {
                upperCaseTotal++;
            } else if (Character.isLowerCase(ch)) {
                lowerCaseTotal++;
            } else if (Character.isDigit(ch)) {
                digitsTotal++;
            } else {
                othersTotal++;
            }
        }
        
        /* Calculate the percentage of the uppercase,lowercase,digits,others characters*/
        
        double upperCasePercentage = (upperCaseTotal * 100) / totalChars;
        double lowerCasePercentage = (lowerCaseTotal * 100) / totalChars;
        double digitsPercentage = (digitsTotal * 100) / totalChars;
        double othersPercentage = (othersTotal * 100) / totalChars;
        DecimalFormat formatter = new DecimalFormat("##.##");
        
        //Printing number and percentage of characters
        
        System.out.println("String is:-" + str);
        System.out.println("Total Characters are:->" + totalChars);
        System.out.println("Number of uppercase letters are:->" + upperCaseTotal + " " + "So percentage is :" + formatter.format(upperCasePercentage) + "%");
        System.out.println("Number of lowercase letters are:->" + lowerCaseTotal + " " + "So percentage is :" + formatter.format(lowerCasePercentage) + "%");
        System.out.println("Number of digits are:->" + digitsTotal + " " + "So percentage is :" + formatter.format(digitsPercentage) + "%");
        System.out.println("Number of other letters are:->" + othersTotal + " " + "So percentage is :" + formatter.format(othersPercentage) + "%");
        
    }
    
    public static void main(String[] args) {
        
        Q4 q = new Q4();
        q.characterPercentage();
    }
}
