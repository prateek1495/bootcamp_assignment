
/*A House Enum is created */

enum House {
    OneBHK(200000), TwoBHK(400000), ThreeBHK(500000);
    private double price;
    
    //Constructor of House Enum is called
    House(double p) {
        this.price = p;
    }
    
    //getPrice method is defined to get details
    double getPrice() {
        return price;
    }
}

public class Q9 {
    public static void main(String args[]) {
        System.out.println("All house prices:");
        //Iterate the values of the House enum and get the price of each house.
        for (House h : House.values()) {
            System.out.println(h + " costs " + h.getPrice() + " rupees.");
        }
    }
    
}

