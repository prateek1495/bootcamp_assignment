public class Q7 {
    
    static String firstName = "Prateek";
    static String lastName = "Nagar";
    static int age = 23;
    
    //Static block is created.(Called before the main method)
    static {
        System.out.println("In static Block");
        System.out.println("Firstname is:" + firstName);
        System.out.println("Lastname is:" + lastName);
        System.out.println("Age is:" + age);
        System.out.println("-------");
    
    }
    
    //Static method is created.
    
    public static void display() {
        System.out.println("In static method");
        System.out.println("Firstname is:" + firstName);
        System.out.println("Lastname is:" + lastName);
        System.out.println("Age is:" + age);
    }
    
    public static void main(String[] args) {
        System.out.println("In main");
        System.out.println("Firstname is:" + firstName);
        System.out.println("Lastname is:" + lastName);
        System.out.println("Age is:" + age);
        System.out.println("-------");
        display();
    }
}
