public class Q2 {
    
    String str = "Hello world world session session session";
    
    public void duplicateCount() {
        
        /*
        Split the string with whitespaces and then iterate the array and compare the words using
        the two for loops and increment the counter for each word for counting the no of occurences
        for each word.
        */
        
        String strSplit[] = str.split(" ");
        for (int i = 0; i < strSplit.length; i++) {
            int duplicateWordCount = 0;
            
            for (int j = i + 1; j < strSplit.length; j++) {
                if (strSplit[i].equals(strSplit[j])) {
                    
                    duplicateWordCount++;
                    strSplit[j] = "*";
                }
            }
            if (strSplit[i] != "*") {
                System.out.println(strSplit[i] + "->" + (duplicateWordCount + 1));
            }
            
        }
        
    }
    
    public static void main(String[] args) {
        Q2 q = new Q2();
        System.out.println("No of occurences of words");
        q.duplicateCount();
        //System.out.println("Duplicated Elements Count are"+dwc);
    }
}
