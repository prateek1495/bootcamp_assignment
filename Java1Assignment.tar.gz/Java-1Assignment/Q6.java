public class Q6 {
    
    public static void findElement() {
        int arr[] = {0,0,1,2,4,4,3,3,1};
        int result = arr[0];
        
        // Use the XOR operator to get the single element and discard the duplicate element
        
        for (int i = 1; i < arr.length; i++) {
            result = result ^ arr[i];
        }
        System.out.println("Single Element is :->" + result);
        
      
        /*
        
        Using another method:-
        
        for (int i = 0; i < array.length; i++) {
            int count=0;
            for (int j = 0; j < array.length; j++) {
                if(array[i]==array[j])
                    count++;
                }
            if(count==1)
            {
                System.out.println("The Unique number in the list is "+array[i]);
                break;
            }
          }
        */
    
    
    }
    
    public static void main(String[] args) {
        Q6.findElement();
    }
}
