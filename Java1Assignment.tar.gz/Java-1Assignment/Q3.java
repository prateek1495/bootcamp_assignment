import java.util.Scanner;

public class Q3 {
    
    String str = "Hello World";
    public void characterOccurence(char c)
    {
        //Initializing noOfOccurence with 0
        int noOfOcccurence=0;
       
        noOfOcccurence=str.split(String.valueOf(c),-1).length-1;
        
        // String.valueOf() is used to convert character into String as split() takes String as parameter
        
        System.out.println("No of Ocuurences of character::"+c+" -->"+noOfOcccurence);
    }
    
    public static void main(String[] args) {
        Q3 q=new Q3();
        Scanner sc=new Scanner(System.in);
         char c=sc.next().charAt(0);
        q.characterOccurence(c);
    }
}
