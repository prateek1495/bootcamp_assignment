
public class Q1 {
    
    String str = "Prateek Vats";
    
    public void replaceString()
    {
        String str = "Prateek Vats";
        System.out.println("Original Name :"+str);
        // replace the "Vats" string with "Nagar" string
        System.out.println("Modified Name :"+str.replace("Vats","Nagar"));
    }
    public static void main(String[] args) {
        Q1 q=new Q1();
        q.replaceString();
    }
}

