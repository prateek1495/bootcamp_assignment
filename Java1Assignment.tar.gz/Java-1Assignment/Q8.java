public class Q8 {
    
    String str = "Hello World";
    
    public void stringReverse() {
        
        //Original String
        System.out.println("Original String:-" + str);
        StringBuffer sb = new StringBuffer(str);
        //Reverse method is called of String Buffer to reverse a string.
        StringBuffer revstr = sb.reverse();
        System.out.println("After Reverse:-" + revstr);
        //Delete method is called to delete the substring from the string takes the start and end index.
        System.out.println("Afer deletion from index 4 to 9:" + revstr.delete(4, 10));
        
        
    }
    
    public static void main(String[] args) {
        Q8 q = new Q8();
        q.stringReverse();
    }
}
