public class Q5 {
    
    public void findCommon() {
        int[] arr1 = {4, 7, 3, 9, 2};
        int[] arr2 = {3, 2, 12, 9, 10, 30, 4};
        
        /* Using two loops to iterate the two arrays and compare the value of
        first array with the all the values of other array */
        
        for (int i = 0; i < arr1.length; i++) {
            for (int j = 0; j < arr2.length; j++) {
                if (arr1[i] == arr2[j]) {
                    System.out.println(arr1[i]);
                }
            }
        }
    }
    
    public static void main(String[] args) {
        Q5 q = new Q5();
        q.findCommon();
    }
}
