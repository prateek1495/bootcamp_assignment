public class Q10 {
    
    /* Here sum  operations are overloaded */
    // sum of two integer numbers
    public void sum(int a, int b) {
        System.out.println(a + b);
    }
    
    //sum of two double numbers
    public void sum(double a, double b) {
        System.out.println(a + b);
    }
    
    
    /* Here multiply  operations are overloaded */
    
    //multiply of two integers
    public void multiply(int a, int b) {
        System.out.println(a * b);
    }
    
    //multiply of two float numbers
    public void multiply(float a, float b) {
        System.out.println(a * b);
    }
    
    
    /* Here concat  operations are overloaded */
    
    //concat  two strings
    public void concatString(String a, String b) {
        System.out.println(a.concat(b));
    }
    
    //concat three strings
    public void concatString(String a, String b, String c) {
        System.out.println(a.concat(b).concat(c));
    }
    
    public static void main(String[] args) {
        Q10 q = new Q10();
        q.sum(2, 3);//sum(int,int) called
        
        q.sum(10.0, 12.3);//sum(double,double) called
        
        q.multiply(2, 3);//multiply(int,int) called
        
        q.multiply(2.2f, 3.0f);//multiply(float,float) called
        
        q.concatString("good", "morning");//concat(String,String) called
        
        q.concatString("good", "morning", "prateek");//concat(String,String,String) called
        
    }
}
