//Parent Class
class Bank {
    double amount = 10000.00;
    float rateofinterest = 5.0f;
    
    public void getDetails() {
        System.out.println("In Bank");
        System.out.println("Rate of Interest:" + rateofinterest);
        System.out.println("----");
        
    }
    
}

//Child Class of Bank
class SBI extends Bank {
    float rateofinterest = 3.0f;
    
    // override the base class Bank getDetails method
    @Override
    public void getDetails() {
        System.out.println("In SBI");
        System.out.println("Rate of Interest:" + rateofinterest);
        System.out.println("----");
        
    }
}

//Child Class of Bank
class BOI extends Bank {
    float rateofinterest = 4.0f;
    
    // override the base class Bank getDetails method
    @Override
    public void getDetails() {
        System.out.println("In BOI");
        System.out.println("Rate of Interest:" + rateofinterest);
        System.out.println("----");
    }
    
}

//Child Class of Bank
class ICICI extends Bank {
    float rateofinterest = 6.0f;
    
    // override the base class Bank getDetails method
    @Override
    public void getDetails() {
        System.out.println("In ICICI");
        System.out.println("Rate of Interest:" + rateofinterest);
    }
    
}

public class Q11 {
    public static void main(String[] args) {
        Bank b = new Bank(); //Bank object created
        
        b.getDetails();//Bank method called
        
        SBI sbi = new SBI();//SBI object created
        
        sbi.getDetails();//SBI method called
        
        BOI boi = new BOI();//BOI object created
        
        boi.getDetails();//BOI method called
        
        ICICI icici = new ICICI();//ICICI object created
        
        icici.getDetails();//ICICI method called
    }
    
}