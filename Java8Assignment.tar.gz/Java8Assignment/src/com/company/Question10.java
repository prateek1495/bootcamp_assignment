package com.company;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class Question10 {
    public static void main(String[] args) {
        //List containg integers
        List<Integer> list= Arrays.asList(2,3,5,7,8,9,6);
        Integer sum=0;
        //add all the integers greater than 5 in the list
        //reduce method returns the single result
        sum=list.stream().filter(e->e>5).reduce(0,(x,y)->x+y);
        System.out.println("Sum is"+sum);
    }
}
