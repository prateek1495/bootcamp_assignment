package com.company;

@FunctionalInterface
interface Computation
{
    int sum(int number1,int number2);
}
public class Question2 {
    public static void main(String[] args) {
        Computation comp=(a,b)->a+b;
        System.out.println(comp.sum(7,6));

    }
}
