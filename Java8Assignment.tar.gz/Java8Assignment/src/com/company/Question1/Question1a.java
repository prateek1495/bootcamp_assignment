package com.company.Question1;

@FunctionalInterface
interface Computation
{
    boolean isgreater(int number1,int number2);
}
public class Question1a {
    public static void main(String[] args) {
        //Lambda for the Computation functional interface
        Computation c=(number1,number2)->{
            return number1>number2?true:false;
        };
        System.out.println(c.isgreater(7,6));
    }
}
