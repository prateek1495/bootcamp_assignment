package com.company.Question1;

@FunctionalInterface
interface Computation2
{
    String concatenation(String s1,String s2);

}
public class Question1c{
    public static void main(String[] args) {
        //Lambda for the Computation2 functional interface
        Computation2 c2=(s1,s2)->s1.concat(s2);
        System.out.println(c2.concatenation("Prateek","Nagar"));
    }
}
