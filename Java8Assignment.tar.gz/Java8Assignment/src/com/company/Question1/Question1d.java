package com.company.Question1;

@FunctionalInterface
interface Computation3
{
    String ConverUppercase(String a);

}
public class Question1d {
    public static void main(String[] args) {
        //Lambda for the Computation3 functional interface
        Computation3 c3=s->s.toUpperCase();
        System.out.println(c3.ConverUppercase("hello"));
    }
}
