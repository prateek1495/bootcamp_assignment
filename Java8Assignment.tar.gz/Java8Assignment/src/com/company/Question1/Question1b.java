package com.company.Question1;

@FunctionalInterface
interface Computation1
{
    int incrementedValue(int value);

}
public class Question1b {
    public static void main(String[] args) {
        //Lambda for the Computation1 functional interface
        Computation1 c1=(value)->value+1;
        System.out.println(c1.incrementedValue(10));
    }
}
