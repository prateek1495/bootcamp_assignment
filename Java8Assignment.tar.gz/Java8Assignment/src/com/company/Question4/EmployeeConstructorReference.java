package com.company.Question4;

@FunctionalInterface
interface Employee {
     EmployeeConstructorReference display(String name, Integer age, String city);
}

public class EmployeeConstructorReference {
    String name;
    Integer age;
    String city;

    EmployeeConstructorReference(String name, Integer age, String city) {
        this.name = name;
        this.age = age;
        this.city = city;
    }

    public void show() {
        System.out.println("Name::" + name +" "+ "Age::" + age + " "+"City::" + city);
    }

    public static void main(String[] args) {
        Employee employee = EmployeeConstructorReference::new;
        EmployeeConstructorReference employeeConstructorReference = employee.display("Prateek", 23, "R.K.Puram");
        employeeConstructorReference.show();
    }
}
