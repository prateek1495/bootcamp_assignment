package com.company;

interface ParentInterface
{
    default void display()
    {
        System.out.println("This is the parent interface default method");
    }
}
interface Child1 extends ParentInterface
{
    default void display()
    {
        System.out.println("This is the Child1 interface method");
    }
}
interface Child2 extends ParentInterface
{
    default void display()
    {
        System.out.println("This is the Child2 interface method");
    }
}
public class Question8 implements Child1,Child2 {
    //Override the default method of interface
    public void display()
    {
        System.out.println("This is the class method");
    }

    public static void main(String[] args) {
        Question8 question8=new Question8();
        question8.display();
    }
}
