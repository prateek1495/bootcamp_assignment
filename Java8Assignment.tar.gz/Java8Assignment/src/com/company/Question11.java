package com.company;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Question11 {
    public static void main(String[] args) {
        //List containg integers
        List<Integer> list= Arrays.asList(2,3,5,7,8,9,6);
        Integer avg=0;
        //average of all the integers after doubling each integer in the list
        System.out.println("Average is ::"+list.stream().collect(Collectors.averagingInt(x->x*2)));

    }
}
