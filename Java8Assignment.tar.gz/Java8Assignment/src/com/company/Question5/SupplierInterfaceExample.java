package com.company.Question5;

import java.util.function.Supplier;

public class SupplierInterfaceExample {
    //Static method same as get() method of Supplier functional interface
    public static int result()
    {
        int number1=10;
        int number2=15;
        return number1+number2;
    }
    public static void main(String[] args) {

        //Supplier functional interface that takes nothing but return a result

        Supplier<Integer>supplier=SupplierInterfaceExample::result;  //Static method reference
        Integer result=supplier.get();
        System.out.println("Result"+result);
    }
}
