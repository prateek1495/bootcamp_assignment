package com.company.Question5;

import java.util.function.Consumer;

public class ConsumerInterfaceExample {
    //static method same as accept(T t) method of Supplier functional interface
    public static void display(String str)
    {
        System.out.println(str);
    }

    public static void main(String[] args) {

        //Consumer functional Interface that takes one argument but  not return anything.
        Consumer<String>consumer=ConsumerInterfaceExample::display;//Static method reference
        consumer.accept("Prateek");
    }
}
