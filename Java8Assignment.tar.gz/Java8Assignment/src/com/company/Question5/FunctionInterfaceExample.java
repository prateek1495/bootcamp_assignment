package com.company.Question5;

import java.util.function.Function;

public class FunctionInterfaceExample {
    //Static method same as apply(T t) method of Function functional interface
    public static int incrementValue(int value)
    {
        return value+1;
    }
    public static void main(String[] args) {
        //Function Functional Interface takes an argument and returns a result
        Function<Integer,Integer>function= FunctionInterfaceExample::incrementValue; //Static method reference
        System.out.println(function.apply(10));
    }
}
