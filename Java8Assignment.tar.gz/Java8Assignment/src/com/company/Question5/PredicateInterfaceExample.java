package com.company.Question5;

import java.util.function.Predicate;

public class PredicateInterfaceExample {

    //Static method same as test(T t) method of Predicate Functional Interface
    public static boolean isGreaterthan(int number)
    {
        return number>10;
    }
    public static void main(String[] args) {

        //Predicate Functional Interface takes an argument and returns boolean whether it passes the test or not
        Predicate<Integer>predicate=PredicateInterfaceExample::isGreaterthan; //Static method reference
        System.out.println(predicate.test(20));
    }
}
