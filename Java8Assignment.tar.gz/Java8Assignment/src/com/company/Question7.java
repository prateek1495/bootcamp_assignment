package com.company;

interface DefaultStaticOverride
{

    //default method of interface
    default void display()
    {
        System.out.println("This is the interface default method");
    }
    //static method of interface
    static void show()
    {
        System.out.println("This is the interface static method");
    }
}
public class Question7 {

    //Override the default method of the interface
 public void display()
 {
     System.out.println("This is the Override default method");
 }

    public static void main(String[] args) {
        Question7 question7=new Question7();
        question7.display();//calls the overriden default method
    }
}
