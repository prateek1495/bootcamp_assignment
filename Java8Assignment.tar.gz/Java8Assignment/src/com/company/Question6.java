package com.company;

interface StaticDefaultExample
{

    //default method
    default void display()
    {
        System.out.println("This is the interface default method");
    }

    //static method
    static void show()
    {
        System.out.println("This is the interface static method");
    }
}
public class Question6 implements StaticDefaultExample {
    public static void main(String[] args) {
        Question6 question6=new Question6();
        //access the default method of interface
        question6.display();
        //access static method of interface
        StaticDefaultExample.show();
    }
}
