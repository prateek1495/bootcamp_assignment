package com.company;


//Functional Interface
@FunctionalInterface
interface Calculation {
    int cal(int number1, int number2);

}

public class Question3 {
    //Instance method
    public int add(int number1, int number2) {
        return number1+number2;
    }

    //Instance method
    public int sub(int number1, int number2) {
        return number1-number2;
    }

    //Static method
    public static int multiply(int number1, int number2) {
        return number1*number2;
    }

    public static void main(String[] args) {
        Calculation calculation = new Question3()::add;  //Instance method Reference
        Calculation calculation1 = new Question3()::sub;  //Instance method Reference
        Calculation calculation2 = Question3::multiply;  //Static method Reference
        System.out.println(calculation.cal(3, 4));
        System.out.println(calculation1.cal(4, 2));
        System.out.println(calculation2.cal(3, 5));

    }
}
